#ifndef UTILITIES_H
#define UTILITIES_H
#include "item.h"
int maxBetween(int n1, int n2);
int partition(ITEM **itemList, int left, int right);
void quicksort(ITEM **itemList, int left, int right);
#endif

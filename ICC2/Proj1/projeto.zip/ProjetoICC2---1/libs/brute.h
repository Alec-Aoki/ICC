#ifndef BRUTE_H
#define BRUTE_H
#include "item.h"
#include "utilities.h"
int brute(ITEM **itemList, int maxWeight, int itemsQuantity);
#endif

#include "../item.h"
#include <stdlib.h>
struct item_ {
  int weight;
  float value;
};

ITEM **create_item_list(int numberOfElements) {
  ITEM **list = malloc(sizeof(ITEM *) * numberOfElements);
  if (!(list)) {
    return NULL;
  }
  return list;
}

void free_item_list(ITEM **list, int numberOfElements) {
  if (list) {
    for (int i = 0; i < numberOfElements; i++) {
      free_item(list[i]);
    }
    free(list);
    list = NULL;
  }
}

ITEM *create_item(int weight, float value) {
  ITEM *item = malloc(sizeof(ITEM));
  if (!item) {
    return NULL;
  }
  item->weight = weight;
  item->value = value;
  return item;
}

void free_item(ITEM *item) {
  if (item) {
    free(item);
    item = NULL;
  }
  return;
}

int getWeight(ITEM *item) {
  if (item) {
    return item->weight;
  }
  exit(1);
}

float getValue(ITEM *item) {
  if (item) {
    return item->value;
  }
  exit(1);
}

float getValueperWeight(ITEM *item) {
  if (item) {
    return getValue(item) / getWeight(item);
  }
  exit(1);
}

#include "../brute.h"

int brute(ITEM **itemList, int maxWeight, int itemsQuantity) {
  if (itemsQuantity == 0 || maxWeight == 0) {
    return 0;
  }
  int itemWeight = getWeight(itemList[itemsQuantity - 1]);
  if (itemWeight > maxWeight)
    return brute(itemList, maxWeight, itemsQuantity - 1);
  int bestPathIncludingTheItem =
      getValue(itemList[itemsQuantity - 1]) +
      brute(itemList, maxWeight - itemWeight, itemsQuantity - 1);
  int bestPathExcludingTheItem = brute(itemList, maxWeight, itemsQuantity - 1);
  return maxBetween(bestPathExcludingTheItem, bestPathIncludingTheItem);
}

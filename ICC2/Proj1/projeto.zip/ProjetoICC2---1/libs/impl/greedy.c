#include "../greedy.h"

int greedy(ITEM **itemList, int maxWeight, int itemsQuantity) {
  quicksort(itemList, 0, itemsQuantity - 1);
  float biggestMoneyAmount = 0;
  for (int i = 0; i < itemsQuantity; i++) {
    int itemWeight = getWeight(itemList[i]);
    if (itemWeight <= maxWeight) {
      maxWeight -= itemWeight;
      biggestMoneyAmount += getValue(itemList[i]);
    }
  }
  return biggestMoneyAmount;
}

#include "../utilities.h"

int maxBetween(int n1, int n2) { return n1 >= n2 ? n1 : n2; }

int partition(ITEM **itemList, int left, int right) {
  float pivot = getValueperWeight(itemList[right]);
  int i = left - 1;
  for (int j = left; j <= right - 1; j++) {
    if (getValueperWeight(itemList[j]) > pivot) {
      i++;
      ITEM *temp = itemList[i];
      itemList[i] = itemList[j];
      itemList[j] = temp;
    }
  }
  ITEM *temp = itemList[i + 1];
  itemList[i + 1] = itemList[right];
  itemList[right] = temp;
  return i + 1;
}

void quicksort(ITEM **itemList, int left, int right) {
  if (left < right) {
    int partitionIndex = partition(itemList, left, right);
    quicksort(itemList, left, partitionIndex - 1);
    quicksort(itemList, partitionIndex + 1, right);
  }
  return;
}

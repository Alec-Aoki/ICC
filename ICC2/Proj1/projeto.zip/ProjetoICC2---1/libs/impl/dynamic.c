#include "../dynamic.h"

int dynamic(ITEM **itemList, int maxWeight, int itemQuantity) {
  int dp[itemQuantity + 1][maxWeight + 1];

  for (int i = 0; i <= itemQuantity; i++) {
    for (int weight = 0; weight <= maxWeight; weight++) {
      if (i == 0 || weight == 0) {
        dp[i][weight] = 0;
      } else if (getWeight(itemList[i - 1]) <= weight) {
        dp[i][weight] =
            maxBetween(getValue(itemList[i - 1]) +
                           dp[i - 1][weight - getWeight(itemList[i - 1])],
                       dp[i - 1][weight]);
      } else {
        dp[i][weight] = dp[i - 1][weight];
      }
    }
  }
  return dp[itemQuantity][maxWeight];
}

#ifndef ITEM_H
#define ITEM_H
typedef struct item_ ITEM;
ITEM **create_item_list(int numberOfElements);
void free_item_list(ITEM **list, int numberOfElements);
ITEM *create_item(int weight, float value);
int getWeight(ITEM *item);
float getValue(ITEM *item);
float getValueperWeight(ITEM *item);
void free_item(ITEM *item);
#endif

#ifndef GREEDY_H
#define GREEDY_H
#include "item.h"
#include "utilities.h"

int greedy(ITEM **itemList, int maxWeight, int itemsQuantity);

#endif

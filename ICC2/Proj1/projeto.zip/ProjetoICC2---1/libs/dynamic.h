#ifndef DYNAMIC_H
#define DYNAMIC_H
#include "item.h"
#include "utilities.h"
int dynamic(ITEM **itemList, int maxWeight, int itemsQuantity);

#endif

//#include "../libs/brute.h"
#include "../libs/dynamic.h"
#include "../libs/greedy.h"
#include <stdio.h>
#include <time.h>

int main() {
  clock_t start, end;

  int maxItems = 0;
  float maxWeight = 0;
  scanf(" %d", &maxItems);
  scanf(" %f", &maxWeight);
  ITEM **list = create_item_list(maxItems);

  int weight;
  float value;

  for (int i = 0; i < maxItems; i++) {
    scanf(" %f", &value);
    scanf(" %d", &weight);
    list[i] = create_item(weight, value);
  }

  //start = clock();
  //int result = brute(list, maxWeight, maxItems);
  //end = clock();

  //printf("\nBrute force result: %d\nExecution time: %f\n", result,
  //       (double)(end - start) / CLOCKS_PER_SEC);

  start = clock();
  int result = greedy(list, maxWeight, maxItems);
  end = clock();

  printf("\nGreedy Algorithm result: %d\nExecution time: %f\n", result,
         (double)(end - start) / CLOCKS_PER_SEC);

  start = clock();
  result = dynamic(list, maxWeight, maxItems);
  end = clock();

  printf("\nDynamic Programming Bottom-up result: %d\nExecution time: %f\n\n",
         result, (double)(end - start) / CLOCKS_PER_SEC);

  free_item_list(list, maxItems);

  return 0;
}
